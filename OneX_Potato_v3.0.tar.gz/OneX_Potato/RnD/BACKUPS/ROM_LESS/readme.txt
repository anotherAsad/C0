This version has the complete and operational CPU
